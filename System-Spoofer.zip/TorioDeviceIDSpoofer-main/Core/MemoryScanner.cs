﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace ToriodeviceIDspoofer.Core
{
    public static partial class MemoryScanner
    {
        public static int TargetProcessId { get; set; }

        private const uint MEM_COMMIT = 0x1000;
        private const uint PAGE_READWRITE = 0x04;
        private const uint PAGE_EXECUTE_READWRITE = 0x40;
        private const uint PROCESS_ALL_ACCESS = 0x001F0FFF;

        [LibraryImport("kernel32.dll", SetLastError = true)]
        public static partial nint OpenProcess(uint processAccess, [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle, int processId);

        [LibraryImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool CloseHandle(nint hObject);

        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORY_BASIC_INFORMATION
        {
            public nint BaseAddress;
            public nint AllocationBase;
            public uint AllocationProtect;
            public nuint RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
        }

        [LibraryImport("kernel32.dll", SetLastError = true)]
        public static partial nuint VirtualQueryEx(
            nint hProcess, nint lpAddress,
            out MEMORY_BASIC_INFORMATION lpBuffer, nuint dwLength);

        [LibraryImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool ReadProcessMemory(
            nint hProcess, nint lpBaseAddress,
            byte[] lpBuffer, nuint nSize, out nuint lpNumberOfBytesRead);

        [LibraryImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool WriteProcessMemory(
            nint hProcess, nint lpBaseAddress,
            byte[] lpBuffer, nuint nSize, out nuint lpNumberOfBytesWritten);

        public static string ScanOriginalDeviceIdFromMemory(Action<string>? logCallback = null)
        {
            nint handle = nint.Zero;
            bool closeNeeded = false;

            if (TargetProcessId <= 0)
            {
                var procs = Process.GetProcessesByName("Minecraft.Windows");
                if (procs.Length > 0) TargetProcessId = procs[0].Id;
            }

            if (TargetProcessId > 0)
            {
                handle = OpenProcess(PROCESS_ALL_ACCESS, false, TargetProcessId);
                closeNeeded = true;
            }

            if (handle == nint.Zero)
            {
                logCallback?.Invoke("[MemoryScanner] Target process handle could not be opened for scanning.");
                return string.Empty;
            }

            try
            {
                nuint mbiSize = (nuint)Marshal.SizeOf<MEMORY_BASIC_INFORMATION>();
                nint address = nint.Zero;

                byte[] patternClientId = Encoding.UTF8.GetBytes("\"ClientId\":\"");
                byte[] patternBuildVersionPrefix = Encoding.UTF8.GetBytes("\"BuildVersion\":\"");
                byte[] patternDeviceId = Encoding.UTF8.GetBytes("\"DeviceId\":\"");
                byte[] patternClientIdW = Encoding.Unicode.GetBytes("\"ClientId\":\"");

                while (true)
                {
                    if (VirtualQueryEx(handle, address, out var mbi, mbiSize) == 0)
                        break;

                    long regBase = mbi.BaseAddress.ToInt64();
                    long regSize = (long)mbi.RegionSize;

                    bool isReadable = mbi.State == MEM_COMMIT &&
                                      (mbi.Protect == PAGE_READWRITE || mbi.Protect == PAGE_EXECUTE_READWRITE || mbi.Protect == 0x02);

                    if (isReadable && regSize <= 128 * 1024 * 1024)
                    {
                        byte[] buffer = new byte[regSize];
                        if (ReadProcessMemory(handle, mbi.BaseAddress, buffer, mbi.RegionSize, out var bytesRead) && bytesRead > 0)
                        {
                            int limit = (int)bytesRead;
                            var span = buffer.AsSpan(0, limit);

                            int clientIdx = span.IndexOf(patternClientId);
                            int buildIdx = span.IndexOf(patternBuildVersionPrefix);

                            if (clientIdx != -1 || buildIdx != -1)
                            {
                                int anchor = clientIdx != -1 ? clientIdx : buildIdx;

                                if (clientIdx != -1)
                                {
                                    int valStart = clientIdx + patternClientId.Length;
                                    int valEnd = span.Slice(valStart).IndexOf((byte)'"');
                                    if (valEnd != -1)
                                    {
                                        string clientVal = Encoding.UTF8.GetString(span.Slice(valStart, valEnd));
                                        string extracted = DeviceIDSpooferEngine.ExtractDeviceId(clientVal);
                                        if (!string.IsNullOrEmpty(extracted))
                                        {
                                            logCallback?.Invoke($"[MemoryScanner] Found DeviceId directly in ClientId: {extracted}");
                                            return extracted;
                                        }
                                    }
                                }

                                int scanStart = Math.Max(0, anchor - 512);
                                int scanLen = Math.Min(limit - scanStart, 4096);
                                string regionText = Encoding.UTF8.GetString(span.Slice(scanStart, scanLen));

                                var dynamicMatch = Regex.Match(regionText, @"""BuildVersion""\s*:\s*""[^""]+""\s*,\s*""ClientId""\s*:\s*""([^""]+)""", RegexOptions.IgnoreCase);
                                if (dynamicMatch.Success)
                                {
                                    string extracted = DeviceIDSpooferEngine.ExtractDeviceId(dynamicMatch.Groups[1].Value);
                                    if (!string.IsNullOrEmpty(extracted))
                                    {
                                        logCallback?.Invoke($"[MemoryScanner] Found DeviceId via dynamic BuildVersion+ClientId match: {extracted}");
                                        return extracted;
                                    }
                                }

                                var clientMatch = Regex.Match(regionText, @"""ClientId""\s*:\s*""([0-9a-fA-F-]{32,36})""", RegexOptions.IgnoreCase);
                                if (clientMatch.Success)
                                {
                                    string extracted = DeviceIDSpooferEngine.ExtractDeviceId(clientMatch.Groups[1].Value);
                                    if (!string.IsNullOrEmpty(extracted))
                                    {
                                        logCallback?.Invoke($"[MemoryScanner] Found DeviceId via ClientId regex: {extracted}");
                                        return extracted;
                                    }
                                }

                                var subSpan = span.Slice(scanStart, scanLen);
                                int devIdx = subSpan.IndexOf(patternDeviceId);
                                if (devIdx != -1)
                                {
                                    int valStart = devIdx + patternDeviceId.Length;
                                    int valEnd = subSpan.Slice(valStart).IndexOf((byte)'"');
                                    if (valEnd != -1)
                                    {
                                        string foundId = Encoding.UTF8.GetString(subSpan.Slice(valStart, valEnd));
                                        string clean = DeviceIDSpooferEngine.ExtractDeviceId(foundId);
                                        if (!string.IsNullOrEmpty(clean))
                                        {
                                            logCallback?.Invoke($"[MemoryScanner] Found DeviceId near ClientId: {clean}");
                                            return clean;
                                        }
                                    }
                                }
                            }

                            int clientIdxW = span.IndexOf(patternClientIdW);
                            if (clientIdxW != -1)
                            {
                                int valStart = clientIdxW + patternClientIdW.Length;
                                int subLimit = Math.Min(limit - valStart, 2048);
                                string textW = Encoding.Unicode.GetString(span.Slice(valStart, subLimit));
                                int quoteIdx = textW.IndexOf('"');
                                if (quoteIdx != -1)
                                {
                                    string clientVal = textW.Substring(0, quoteIdx);
                                    string clean = DeviceIDSpooferEngine.ExtractDeviceId(clientVal);
                                    if (!string.IsNullOrEmpty(clean))
                                    {
                                        logCallback?.Invoke($"[MemoryScanner] Found DeviceId in UTF-16 ClientId: {clean}");
                                        return clean;
                                    }
                                }
                            }
                        }
                    }

                    long next = regBase + regSize;
                    if (next <= 0 || next >= 0x7FFFFFFFFFFFFFFF) break;
                    address = (nint)next;
                    if ((ulong)(nuint)address >= 0x7FFFFFFF0000UL) break;
                }

                return string.Empty;
            }
            finally
            {
                if (closeNeeded && handle != nint.Zero)
                    CloseHandle(handle);
            }
        }

        public static int ReplaceDeviceIDsInMemory(List<string> originalIds, string newId, Action<string>? logCallback = null)
        {
            nint handle = nint.Zero;
            bool closeNeeded = false;

            if (TargetProcessId <= 0)
            {
                var procs = Process.GetProcessesByName("Minecraft.Windows");
                if (procs.Length > 0) TargetProcessId = procs[0].Id;
            }

            if (TargetProcessId > 0)
            {
                handle = OpenProcess(PROCESS_ALL_ACCESS, false, TargetProcessId);
                closeNeeded = true;
            }

            if (handle == nint.Zero)
            {
                logCallback?.Invoke("[MemoryScanner] Target process handle could not be opened.");
                return 0;
            }

            try
            {
                var targets = new List<byte[]>();
                foreach (var id in originalIds)
                {
                    if (!string.IsNullOrEmpty(id))
                        targets.Add(Encoding.ASCII.GetBytes(id));
                }

                if (targets.Count == 0) return 0;

                byte[] replacementBytes = Encoding.ASCII.GetBytes(newId);
                int replacedCount = 0;
                nint address = nint.Zero;
                nuint mbiSize = (nuint)Marshal.SizeOf<MEMORY_BASIC_INFORMATION>();

                while (true)
                {
                    if (VirtualQueryEx(handle, address, out var mbi, mbiSize) == 0)
                        break;

                    long regBase = mbi.BaseAddress.ToInt64();
                    long regSize = (long)mbi.RegionSize;

                    bool isWritable = mbi.State == MEM_COMMIT &&
                                      (mbi.Protect == PAGE_READWRITE || mbi.Protect == PAGE_EXECUTE_READWRITE);

                    if (isWritable && regSize <= 256 * 1024 * 1024)
                    {
                        byte[] buffer = new byte[regSize];
                        if (ReadProcessMemory(handle, mbi.BaseAddress, buffer, mbi.RegionSize, out var bytesRead) && bytesRead > 0)
                        {
                            int limit = (int)bytesRead;
                            var span = buffer.AsSpan(0, limit);

                            for (int tIdx = 0; tIdx < targets.Count; tIdx++)
                            {
                                byte[] targetBytes = targets[tIdx];
                                int targetLen = targetBytes.Length;
                                int offset = 0;

                                while (offset <= limit - targetLen)
                                {
                                    int matchIdx = span.Slice(offset).IndexOf(targetBytes);
                                    if (matchIdx == -1)
                                        break;

                                    int foundIdx = offset + matchIdx;
                                    nint targetAddr = mbi.BaseAddress + foundIdx;
                                    if (WriteProcessMemory(handle, targetAddr, replacementBytes, (nuint)replacementBytes.Length, out _))
                                    {
                                        replacedCount++;
                                    }
                                    offset = foundIdx + targetLen;
                                }
                            }
                        }
                    }

                    long next = regBase + regSize;
                    if (next <= 0 || next >= 0x7FFFFFFFFFFFFFFF) break;
                    address = (nint)next;
                    if ((ulong)(nuint)address >= 0x7FFFFFFF0000UL) break;
                }

                logCallback?.Invoke($"[MemoryScanner] Scan complete. Replaced {replacedCount} occurrences.");
                return replacedCount;
            }
            finally
            {
                if (closeNeeded && handle != nint.Zero)
                    CloseHandle(handle);
            }
        }
    }
}