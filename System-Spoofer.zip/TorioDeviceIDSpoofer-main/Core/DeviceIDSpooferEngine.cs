﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ToriodeviceIDspoofer.Network;

namespace ToriodeviceIDspoofer.Core
{
    public class DeviceIDSpooferEngine
    {
        private static DeviceIDSpooferEngine? _instance;
        public static DeviceIDSpooferEngine Instance => _instance ??= new DeviceIDSpooferEngine();

        private readonly object _lockObj = new();
        private bool _enabled = true;
        private string _originalDeviceId = string.Empty;
        private bool _spoofOnJoin = false;
        private bool _spoofOnStartup;
        private string? _spoofedDeviceId;
        private string? _lastSeenDeviceId;
        private DateTime _lastReplacementTime = DateTime.MinValue;
        private bool _startupSpoofDone;

        private readonly ConcurrentDictionary<int, List<Fragment>> _fragments = new();

        public bool IsEnabled { get => _enabled; set => _enabled = value; }
        public string OriginalDeviceId { get => _originalDeviceId; set => _originalDeviceId = value; }
        public string? SpoofedDeviceId => _spoofedDeviceId;
        public bool SpoofOnJoin { get => _spoofOnJoin; set => _spoofOnJoin = value; }
        public bool SpoofOnStartup { get => _spoofOnStartup; set => _spoofOnStartup = value; }

        public event Action<string>? OnLog;
        public event Action<string>? OnSpoofUpdated;

        private class Fragment
        {
            public int Index { get; set; }
            public int Count { get; set; }
            public byte[] Payload { get; set; } = Array.Empty<byte>();
        }

        public void Initialize()
        {
            _originalDeviceId = FetchDefaultDeviceIdFromCredentials();
            if (!string.IsNullOrEmpty(_originalDeviceId))
            {
                OnLog?.Invoke($"[Engine] Original Device ID fetched from Windows Credentials: {_originalDeviceId}");
            }
            else
            {
                OnLog?.Invoke("[Engine] Initialized. Original Device ID will be auto-scanned from memory.");
            }

            NetworkHookManager.Instance.OnPacketReceived += HandlePacket;
            NetworkHookManager.Instance.OnLog += msg => OnLog?.Invoke(msg);
        }

        public void Apply(bool enabled, string originalId, bool spoofOnJoin, bool spoofOnStartup)
        {
            bool wasEnabled;
            string oldOriginalId;
            lock (_lockObj)
            {
                wasEnabled = _enabled;
                oldOriginalId = _originalDeviceId;

                _enabled = enabled;
                if (!string.IsNullOrEmpty(originalId))
                {
                    _originalDeviceId = originalId.Trim().ToLowerInvariant();
                }
                _spoofOnJoin = spoofOnJoin;
                _spoofOnStartup = spoofOnStartup;
            }

            if (enabled)
            {
                lock (_lockObj) { _startupSpoofDone = false; }

                if (!wasEnabled || (!string.IsNullOrEmpty(originalId) && oldOriginalId != _originalDeviceId))
                {
                    lock (_lockObj) { _lastReplacementTime = DateTime.MinValue; }
                    GenerateAndReplaceDeviceId("Settings Apply");
                }
                else if (_spoofOnStartup && !_startupSpoofDone)
                {
                    _startupSpoofDone = true;
                    GenerateAndReplaceDeviceId("Startup");
                }
            }
            else
            {
                string? oldSpoofed;
                string? orig;
                lock (_lockObj)
                {
                    oldSpoofed = _spoofedDeviceId;
                    orig = _originalDeviceId;

                    _spoofedDeviceId = null;
                    _lastSeenDeviceId = null;
                    _startupSpoofDone = false;
                    _fragments.Clear();
                }

                if (!string.IsNullOrEmpty(oldSpoofed) && !string.IsNullOrEmpty(orig))
                {
                    Task.Run(() =>
                    {
                        try
                        {
                            MemoryScanner.ReplaceDeviceIDsInMemory(new List<string> { oldSpoofed }, orig, msg => OnLog?.Invoke(msg));
                        }
                        catch { }
                    });
                }
            }
        }

        public static string ExtractDeviceId(string? input)
        {
            if (string.IsNullOrWhiteSpace(input)) return string.Empty;
            string text = input.Trim();

            var didMatch = Regex.Match(text, @"(?:DID|Device\s*ID)\s*[:=]?\s*([0-9a-fA-F-]{32,36})", RegexOptions.IgnoreCase);
            if (didMatch.Success)
            {
                return didMatch.Groups[1].Value.Replace("-", "").ToLowerInvariant();
            }

            var hex32Match = Regex.Match(text, @"\b([0-9a-fA-F]{32})\b", RegexOptions.IgnoreCase);
            if (hex32Match.Success)
            {
                return hex32Match.Groups[1].Value.ToLowerInvariant();
            }

            var guidMatch = Regex.Match(text, @"\b([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\b", RegexOptions.IgnoreCase);
            if (guidMatch.Success)
            {
                return guidMatch.Groups[1].Value.Replace("-", "").ToLowerInvariant();
            }

            var continuousHex = Regex.Match(text, @"[0-9a-fA-F]{32}", RegexOptions.IgnoreCase);
            if (continuousHex.Success)
            {
                return continuousHex.Value.ToLowerInvariant();
            }

            return text.Trim();
        }

        public static string GenerateRandomDeviceId()
        {
            byte[] bytes = new byte[16];
            Random.Shared.NextBytes(bytes);
            return Convert.ToHexString(bytes).ToLower();
        }

        public void GenerateAndReplaceDeviceId(string triggerContext)
        {
            string origId;
            string? oldSpoofedId;
            string? lastSeenId;

            lock (_lockObj)
            {
                if (string.IsNullOrEmpty(_originalDeviceId))
                {
                    _originalDeviceId = FetchDefaultDeviceIdFromCredentials();
                }

                origId = _originalDeviceId;
                oldSpoofedId = _spoofedDeviceId;
                lastSeenId = _lastSeenDeviceId;

                if (DateTime.UtcNow - _lastReplacementTime < TimeSpan.FromSeconds(2))
                    return;

                _lastReplacementTime = DateTime.UtcNow;
                _spoofedDeviceId = GenerateRandomDeviceId();
            }

            string newSpoofedId = _spoofedDeviceId;
            OnLog?.Invoke($"[Engine] Generating new Spoofed Device ID ({triggerContext}): {newSpoofedId}");
            OnSpoofUpdated?.Invoke(newSpoofedId);

            Task.Run(() =>
            {
                try
                {
                    if (string.IsNullOrEmpty(origId))
                    {
                        origId = MemoryScanner.ScanOriginalDeviceIdFromMemory(msg => OnLog?.Invoke(msg));
                        if (!string.IsNullOrEmpty(origId))
                        {
                            lock (_lockObj) { _originalDeviceId = origId; }
                        }
                    }

                    var targets = new List<string>();
                    if (!string.IsNullOrEmpty(origId)) targets.Add(origId);

                    string defaultCredId = FetchDefaultDeviceIdFromCredentials();
                    if (!string.IsNullOrEmpty(defaultCredId) && !targets.Contains(defaultCredId))
                    {
                        targets.Add(defaultCredId);
                    }

                    if (!string.IsNullOrEmpty(oldSpoofedId) && !targets.Contains(oldSpoofedId)) targets.Add(oldSpoofedId);
                    if (!string.IsNullOrEmpty(lastSeenId) && !targets.Contains(lastSeenId)) targets.Add(lastSeenId);

                    string memScannedId = MemoryScanner.ScanOriginalDeviceIdFromMemory(msg => OnLog?.Invoke(msg));
                    if (!string.IsNullOrEmpty(memScannedId) && !targets.Contains(memScannedId))
                    {
                        targets.Add(memScannedId);
                        if (string.IsNullOrEmpty(origId))
                        {
                            lock (_lockObj) { _originalDeviceId = memScannedId; }
                        }
                    }

                    if (targets.Count == 0)
                    {
                        OnLog?.Invoke($"[Engine] Triggered by {triggerContext}. Original Device ID could not be found in memory or credentials yet.");
                        return;
                    }

                    int count = MemoryScanner.ReplaceDeviceIDsInMemory(targets, newSpoofedId, msg => OnLog?.Invoke(msg));

                    if (count > 0)
                    {
                        OnLog?.Invoke($"[Engine] Successfully spoofed {count} memory locations to '{newSpoofedId}'");
                    }
                    else
                    {
                        OnLog?.Invoke($"[Engine] Device ID target not currently in memory. (Will auto-replace when packet is parsed)");
                    }
                }
                catch (Exception ex)
                {
                    OnLog?.Invoke($"[Engine] Replacement error: {ex.Message}");
                }
            });
        }

        public string FetchDefaultDeviceIdFromCredentials()
        {
            try
            {
                if (CredReadW("Microsoft\\Xbox\\Settings\\DeviceId", 1, 0, out nint credPtr))
                {
                    try
                    {
                        var cred = Marshal.PtrToStructure<CREDENTIAL>(credPtr);
                        if (cred.CredentialBlobSize > 0 && cred.CredentialBlob != nint.Zero)
                        {
                            byte[] blob = new byte[cred.CredentialBlobSize];
                            Marshal.Copy(cred.CredentialBlob, blob, 0, (int)cred.CredentialBlobSize);

                            string str = Encoding.Unicode.GetString(blob).TrimEnd('\0');
                            if (str.Contains("\0") || str.Length < 32 || str.Length > 40)
                            {
                                str = Encoding.UTF8.GetString(blob).TrimEnd('\0');
                            }
                            return str;
                        }
                    }
                    finally
                    {
                        CredFree(credPtr);
                    }
                }
            }
            catch (Exception ex)
            {
                OnLog?.Invoke($"[Engine] Failed to read credentials: {ex.Message}");
            }
            return string.Empty;
        }

        private void HandlePacket(string direction, byte[] data)
        {
            if (data.Length == 0) return;

            if (_enabled && _spoofOnStartup && !_startupSpoofDone)
            {
                lock (_lockObj) { _startupSpoofDone = true; }
                GenerateAndReplaceDeviceId("Startup Packet");
            }

            byte pid = data[0];
            if (pid == 0x05)
            {
                _fragments.Clear();
                if (_enabled && _spoofOnJoin)
                {
                    GenerateAndReplaceDeviceId("Server Join");
                }
            }
            else if (pid == 0x15 || pid == 0x16)
            {
                _fragments.Clear();
            }
            else if (pid >= 0x80 && pid <= 0x8f)
            {
                ParseRaknetFrames(direction, data);
            }
        }

        private void ParseRaknetFrames(string direction, byte[] data)
        {
            if (data.Length < 5) return;
            int offset = 4;
            while (offset < data.Length)
            {
                if (offset + 3 > data.Length) break;
                byte flags = data[offset];
                int reliability = flags >> 5;
                bool isFragment = (flags & 0x10) != 0;
                int length = (((data[offset + 1] << 8) | data[offset + 2]) + 7) / 8;
                offset += 3;

                if (reliability == 2 || reliability == 3 || reliability == 4 || reliability == 6 || reliability == 7) offset += 3;
                if (reliability == 1 || reliability == 4) offset += 3;
                if (reliability == 3 || reliability == 4 || reliability == 7) offset += 4;

                if (isFragment)
                {
                    if (offset + 12 > data.Length) break;
                    int fc = (data[offset] << 24) | (data[offset + 1] << 16) | (data[offset + 2] << 8) | data[offset + 3];
                    int fg = (data[offset + 4] << 8) | data[offset + 5];
                    int fi = (data[offset + 6] << 24) | (data[offset + 7] << 16) | (data[offset + 8] << 8) | data[offset + 9];
                    offset += 10;

                    if (offset + length > data.Length) break;
                    byte[] payload = new byte[length];
                    Array.Copy(data, offset, payload, 0, length);
                    offset += length;

                    var list = _fragments.GetOrAdd(fg, _ => new List<Fragment>());
                    lock (list)
                    {
                        list.Add(new Fragment { Index = fi, Count = fc, Payload = payload });
                        if (list.Count == fc)
                        {
                            _fragments.TryRemove(fg, out _);
                            var reassembled = list.OrderBy(f => f.Index).SelectMany(f => f.Payload).ToArray();
                            ExtractDeviceIdFromPayload(direction, reassembled);
                        }
                    }

                    if (_fragments.Count > 128) _fragments.Clear();
                }
                else
                {
                    if (offset + length > data.Length) break;
                    byte[] payload = new byte[length];
                    Array.Copy(data, offset, payload, 0, length);
                    offset += length;

                    ExtractDeviceIdFromPayload(direction, payload);
                }
            }
        }

        private void ExtractDeviceIdFromPayload(string direction, byte[] payload)
        {
            if (payload.Length < 3) return;

            if (payload[0] == 0xfe)
            {
                byte[]? decompressed = DecompressPayload(payload);
                if (decompressed != null && decompressed.Length > 0)
                {
                    SearchAndExtractFromBytes(direction, decompressed);
                }
            }

            SearchAndExtractFromBytes(direction, payload);
        }

        private byte[]? DecompressPayload(byte[] payload)
        {
            if (payload.Length <= 2) return null;
            try
            {
                using var ms = new MemoryStream(payload, 2, payload.Length - 2);
                using var zlib = new ZLibStream(ms, CompressionMode.Decompress);
                using var outMs = new MemoryStream();
                zlib.CopyTo(outMs);
                return outMs.ToArray();
            }
            catch { }

            try
            {
                using var ms = new MemoryStream(payload, 2, payload.Length - 2);
                using var deflate = new DeflateStream(ms, CompressionMode.Decompress);
                using var outMs = new MemoryStream();
                deflate.CopyTo(outMs);
                return outMs.ToArray();
            }
            catch { }

            return null;
        }

        private void SearchAndExtractFromBytes(string direction, byte[] bytes)
        {
            try
            {
                string rawStr = Encoding.UTF8.GetString(bytes);
                var matches = Regex.Matches(rawStr, @"eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_=]*");
                foreach (Match match in matches)
                {
                    string token = match.Value;
                    string[] parts = token.Split('.');
                    if (parts.Length < 2) continue;

                    byte[] bodyBytes;
                    try
                    {
                        string pad = parts[1].Replace('-', '+').Replace('_', '/');
                        switch (pad.Length % 4)
                        {
                            case 2: pad += "=="; break;
                            case 3: pad += "="; break;
                        }
                        bodyBytes = Convert.FromBase64String(pad);
                    }
                    catch { continue; }

                    string bodyStr = Encoding.UTF8.GetString(bodyBytes);
                    using var doc = JsonDocument.Parse(bodyStr);
                    var root = doc.RootElement;

                    if (root.TryGetProperty("DeviceId", out var did))
                    {
                        string? deviceId = did.GetString();
                        if (!string.IsNullOrEmpty(deviceId))
                        {
                            OnLog?.Invoke($"[Engine] Intercepted Packet DeviceId: {deviceId}");
                            lock (_lockObj)
                            {
                                _lastSeenDeviceId = deviceId;
                                if (_enabled && !string.IsNullOrEmpty(_spoofedDeviceId) && deviceId != _spoofedDeviceId)
                                {
                                    Task.Run(() =>
                                    {
                                        var targets = new List<string> { _originalDeviceId };
                                        if (!string.IsNullOrEmpty(_spoofedDeviceId)) targets.Add(_spoofedDeviceId);
                                        MemoryScanner.ReplaceDeviceIDsInMemory(targets, _spoofedDeviceId);
                                    });
                                }
                            }
                        }
                    }
                }
            }
            catch { }
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct CREDENTIAL
        {
            public uint Flags;
            public uint Type;
            public string TargetName;
            public string Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public uint CredentialBlobSize;
            public nint CredentialBlob;
            public uint Persist;
            public uint AttributeCount;
            public nint Attributes;
            public string TargetAlias;
            public string UserName;
        }

        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredReadW", CharSet = CharSet.Unicode)]
        private static extern bool CredReadW(string targetName, uint type, uint reservedFlag, out nint credentialPtr);

        [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredFree")]
        private static extern void CredFree(nint buffer);
    }
}