using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Frida;

namespace ToriodeviceIDspoofer.Network
{
    public class NetworkHookManager : IDisposable
    {
        private static NetworkHookManager? _instance;
        public static NetworkHookManager Instance => _instance ??= new NetworkHookManager();

        private DeviceManager? _deviceManager;
        private Device? _localDevice;
        private Session? _session;
        private Script? _script;
        private bool _isHooked;

        public bool IsHooked => _isHooked;
        public event Action<string, byte[]>? OnPacketReceived;
        public event Action<string>? OnLog;

        public void Initialize()
        {
            FridaLoader.Initialize();
        }

        public void StartHook()
        {
            if (_isHooked) return;

            try
            {
                var processes = System.Diagnostics.Process.GetProcessesByName("Minecraft.Windows");
                if (processes.Length == 0)
                {
                    OnLog?.Invoke("[Hook] Minecraft.Windows.exe process not found.");
                    return;
                }

                int pid = processes[0].Id;
                Core.MemoryScanner.TargetProcessId = pid;

                if (_deviceManager == null)
                    _deviceManager = new DeviceManager();

                _localDevice = _deviceManager.EnumerateDevices().FirstOrDefault(d => d.Type == DeviceType.Local);
                if (_localDevice == null)
                {
                    OnLog?.Invoke("[Hook] Local device not found.");
                    return;
                }

                _session = _localDevice.Attach((uint)pid);

                string scriptText = GetEmbeddedScript("Network.js");
                _script = _session.CreateScript(scriptText);
                _script.Message += OnScriptMessage;
                _script.Load();

                _isHooked = true;
                OnLog?.Invoke($"[Hook] Successfully attached Frida to Process ID {pid}");
            }
            catch (Exception ex)
            {
                OnLog?.Invoke($"[Hook] Attach Failed: {ex.Message}");
                StopHook();
            }
        }

        public void StopHook()
        {
            try
            {
                if (_script != null)
                {
                    try { _script.Unload(); } catch { }
                    _script = null;
                }
                if (_session != null)
                {
                    try { _session.Detach(); } catch { }
                    _session = null;
                }

                Device? localDevice = _localDevice;
                DeviceManager? deviceManager = _deviceManager;

                _localDevice = null;
                _deviceManager = null;

                if (deviceManager != null) GC.SuppressFinalize(deviceManager);
                try { localDevice?.Dispose(); } catch { }
                try { deviceManager?.Dispose(); } catch { }

                _isHooked = false;
                OnLog?.Invoke("[Hook] Detached from process.");
            }
            catch (Exception ex)
            {
                OnLog?.Invoke($"[Hook] Error during detach: {ex.Message}");
            }
        }

        private void OnScriptMessage(object? sender, ScriptMessageEventArgs e)
        {
            try
            {
                using var doc = JsonDocument.Parse(e.Message);
                var root = doc.RootElement;
                if (root.TryGetProperty("type", out var typeProp) && typeProp.GetString() == "send")
                {
                    if (root.TryGetProperty("payload", out var payload))
                    {
                        if (payload.TryGetProperty("type", out var msgType) && msgType.GetString() == "PACKET")
                        {
                            string dir = payload.GetProperty("direction").GetString() ?? "";
                            string hex = payload.GetProperty("hex").GetString() ?? "";
                            byte[] data = ConvertFromHex(hex);

                            OnPacketReceived?.Invoke(dir, data);
                        }
                    }
                }
            }
            catch { }
        }

        private static byte[] ConvertFromHex(string hex)
        {
            int rawLength = hex.Length;
            byte[] bytes = new byte[rawLength / 2];
            for (int i = 0; i < rawLength; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }

        private string GetEmbeddedScript(string resourceName)
        {
            var asm = Assembly.GetExecutingAssembly();
            string fullResourceName = asm.GetManifestResourceNames().FirstOrDefault(n => n.EndsWith(resourceName)) ?? resourceName;
            using var stream = asm.GetManifestResourceStream(fullResourceName);
            if (stream == null) throw new FileNotFoundException($"Resource {resourceName} not found.");
            using var reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }

        public void Dispose()
        {
            StopHook();
        }
    }
}
