let config = {};

const ws2 = Module.load('WS2_32.dll');
const nativeSendto = new NativeFunction(ws2.getExportByName('sendto'), 'int', ['pointer', 'pointer', 'int', 'int', 'pointer', 'int']);

function dumpOfInterest(d, p, l) {
    if (l <= 0 || l > 4096) return;
    try {
        var firstByte = p.readU8();
        if (firstByte === 0x05 || firstByte === 0x06 || firstByte === 0x07 || firstByte === 0x08 || firstByte === 0x15 || firstByte === 0x16 || (firstByte >= 0x80 && firstByte <= 0x8f)) {
            if (d === 'RECV' && firstByte >= 0x80 && firstByte <= 0x8f) {
                return;
            }
            var b = p.readByteArray(l), u = new Uint8Array(b), h = '';
            for (var i = 0; i < u.length; i++) h += ('0' + u[i].toString(16)).slice(-2);
            send({ type: 'PACKET', direction: d, hex: h });
        }
    } catch (e) { }
}

Interceptor.attach(ws2.getExportByName('recvfrom'), {
    onEnter: function (args) {
        this.sock = args[0];
        this.buf = args[1];
        this.bufLen = args[2].toInt32();
        this.flags = args[3];
        this.from = args[4];
        this.fromlen = args[5];
    },
    onLeave: function (retval) {
        let n = retval.toInt32();
        if (n > 0) {
            dumpOfInterest('RECV', this.buf, n);
        }
    }
});

Interceptor.replace(ws2.getExportByName('sendto'), new NativeCallback(function (sock, buf, len, flags, addr, addrlen) {
    dumpOfInterest('SEND', buf, len);
    return nativeSendto(sock, buf, len, flags, addr, addrlen);
}, 'int', ['pointer', 'pointer', 'int', 'int', 'pointer', 'int']));
