using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;

namespace ToriodeviceIDspoofer.Network
{
    public static class FridaLoader
    {
        private static bool _initialized;
        private static string? _extractedPath;
        private static readonly object _initLock = new();

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool SetDllDirectory(string lpPathName);

        public static void Initialize()
        {
            lock (_initLock)
            {
                if (_initialized) return;
                _initialized = true;

                _extractedPath = ExtractEmbeddedNativeLibs();

                if (!string.IsNullOrEmpty(_extractedPath) && Directory.Exists(_extractedPath))
                {
                    try
                    {
                        SetDllDirectory(_extractedPath);
                        string? pathEnv = Environment.GetEnvironmentVariable("PATH");
                        Environment.SetEnvironmentVariable("PATH", _extractedPath + ";" + pathEnv);
                    }
                    catch { }

                    AssemblyLoadContext.Default.Resolving += Default_Resolving;
                }
            }
        }

        private static Assembly? Default_Resolving(AssemblyLoadContext context, AssemblyName assemblyName)
        {
            if (assemblyName.Name != null && (assemblyName.Name.Equals("Frida", StringComparison.OrdinalIgnoreCase) || assemblyName.Name.Equals("FridaNet", StringComparison.OrdinalIgnoreCase)))
            {
                if (string.IsNullOrEmpty(_extractedPath) || !Directory.Exists(_extractedPath))
                {
                    _extractedPath = ExtractEmbeddedNativeLibs();
                }

                if (!string.IsNullOrEmpty(_extractedPath))
                {
                    string dllPath = Path.Combine(_extractedPath, "Frida.dll");
                    if (!File.Exists(dllPath))
                    {
                        ExtractResource("Frida.dll", dllPath);
                        ExtractResource("ijwhost.dll", Path.Combine(_extractedPath, "ijwhost.dll"));
                    }

                    if (File.Exists(dllPath))
                    {
                        try
                        {
                            return context.LoadFromAssemblyPath(dllPath);
                        }
                        catch { }
                    }
                }
            }
            return null;
        }

        private static string ExtractEmbeddedNativeLibs()
        {
            try
            {
                string baseDir = Path.Combine(Path.GetTempPath(), "TorioDeviceIDSpoofer_Native");
                CleanupOldDirectories(baseDir);

                string extractDir = Path.Combine(baseDir, Process.GetCurrentProcess().Id.ToString());

                if (!Directory.Exists(extractDir))
                {
                    Directory.CreateDirectory(extractDir);
                }

                ExtractResource("Frida.dll", Path.Combine(extractDir, "Frida.dll"));
                ExtractResource("ijwhost.dll", Path.Combine(extractDir, "ijwhost.dll"));

                return extractDir;
            }
            catch
            {
                return AppDomain.CurrentDomain.BaseDirectory;
            }
        }

        private static void ExtractResource(string resourceName, string outPath)
        {
            try
            {
                var asm = typeof(FridaLoader).Assembly;
                string? actualResourceName = asm.GetManifestResourceNames()
                    .FirstOrDefault(n => n.Equals(resourceName, StringComparison.OrdinalIgnoreCase) || n.EndsWith("." + resourceName, StringComparison.OrdinalIgnoreCase));

                using Stream? stream = actualResourceName != null ? asm.GetManifestResourceStream(actualResourceName) : null;
                if (stream != null)
                {
                    using FileStream fileStream = new FileStream(outPath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
                    stream.CopyTo(fileStream);
                }
            }
            catch { }
        }

        private static void CleanupOldDirectories(string baseDir)
        {
            try
            {
                if (!Directory.Exists(baseDir)) return;

                foreach (var dir in Directory.GetDirectories(baseDir))
                {
                    try
                    {
                        Directory.Delete(dir, true);
                    }
                    catch { }
                }
            }
            catch { }
        }

        public static void Cleanup()
        {
            if (string.IsNullOrEmpty(_extractedPath) || !Directory.Exists(_extractedPath))
                return;

            try
            {
                try
                {
                    Directory.Delete(_extractedPath, true);
                    string baseDir = Path.Combine(Path.GetTempPath(), "TorioDeviceIDSpoofer_Native");
                    if (Directory.Exists(baseDir) && Directory.GetFileSystemEntries(baseDir).Length == 0)
                    {
                        Directory.Delete(baseDir, true);
                    }
                    return;
                }
                catch { }

                string targetPath = _extractedPath;
                string baseDirFallback = Path.Combine(Path.GetTempPath(), "TorioDeviceIDSpoofer_Native");

                string cmdArgs = $"/c ping 127.0.0.1 -n 2 >nul & (if exist \"{targetPath}\" rmdir /s /q \"{targetPath}\") & (if exist \"{baseDirFallback}\" rmdir \"{baseDirFallback}\" 2>nul)";

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = cmdArgs,
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                Process.Start(psi);
            }
            catch { }
        }
    }
}
