﻿# Torio Device ID Spoofer

A lightweight standalone Device ID spoofer designed for Minecraft (Windows / Bedrock edition).  
It dynamically monitors target process memory and network frames (RakNet) to mask your device identifier.

---

## Features

- **Zero-Configuration & Full Auto Detection**:
  - No manual device ID input or configuration file required.
  - Automatically scans and resolves your original device identifier from process memory (`"BuildVersion": "...", "ClientId": "..."`) and Windows Credential Manager.
- **Instant One-Click Spoof**:
  - Click the **[Spoof]** button to immediately replace your device identifier in process memory with a randomly generated device ID.
- **Auto Process Monitor**:
  - Automatically monitors and hooks into `Minecraft.Windows.exe` upon launching.
- **Auto Spoof on Server Join (Toggleable)**:
  - Intercepts connection packets and automatically randomizes your device ID whenever you join a server (Default: **OFF**).
- **Single Instance (Mutex Protection)**:
  - Prevents multiple instances from running simultaneously to avoid conflicting memory hooks.

---

## Usage

1. **Launch Minecraft** (Windows edition).
2. **Open `ToriodeviceIDspoofer.exe`**.
   - The indicator will turn yellow: `Game Detected (Ready to Spoof)`.
3. **Click [Spoof]**.
   - Your device ID in memory will be automatically scanned and replaced with a newly randomized identifier.
   - The indicator will turn green: `Game Detected (Spoofed)`.
4. **Auto Spoof on Server Join**:
   - If you want a new randomized device ID every time you join a server, toggle the **Auto Spoof on Server Join** switch **ON**.

---

## Screenshots

![Torio Device ID Spoofer UI](screenshots/preview2.png)

---

## Build from Source

To build the standalone single-file executable:

```powershell
dotnet publish ToriodeviceIDspoofer.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

The output single `.exe` file will be generated in:  
`bin/Release/net9.0-windows10.0.19041.0/win-x64/publish/ToriodeviceIDspoofer.exe`

---

## License

This project is licensed under the **GNU General Public License v3.0 (GPL-3.0)**.  
See the [LICENSE](./LICENSE) file for details.