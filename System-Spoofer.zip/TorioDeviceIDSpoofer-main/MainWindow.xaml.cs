﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using ToriodeviceIDspoofer.Core;
using ToriodeviceIDspoofer.Network;

namespace ToriodeviceIDspoofer
{
    public partial class MainWindow : Window
    {
        private readonly DispatcherTimer _processWatcher;
        private bool _isLoading = true;
        private bool _isSpoofed = false;

        public MainWindow()
        {
            InitializeComponent();

            DeviceIDSpooferEngine.Instance.Initialize();
            DeviceIDSpooferEngine.Instance.OnSpoofUpdated += newId =>
            {
                Dispatcher.Invoke(() =>
                {
                    _isSpoofed = true;
                    UpdateStatusUi();
                });
            };

            ApplyCurrentSettings();
            _isLoading = false;

            _processWatcher = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _processWatcher.Tick += ProcessWatcher_Tick;
            _processWatcher.Start();

            CheckAndHookProcess();
        }

        private void ProcessWatcher_Tick(object? sender, EventArgs e)
        {
            CheckAndHookProcess();
        }

        private void CheckAndHookProcess()
        {
            var procs = Process.GetProcessesByName("Minecraft.Windows");
            if (procs.Length > 0)
            {
                if (!NetworkHookManager.Instance.IsHooked)
                {
                    NetworkHookManager.Instance.StartHook();
                }
            }
            else
            {
                if (NetworkHookManager.Instance.IsHooked)
                {
                    NetworkHookManager.Instance.StopHook();
                }
                _isSpoofed = false;
            }

            UpdateStatusUi();
        }

        private void UpdateStatusUi()
        {
            var procs = Process.GetProcessesByName("Minecraft.Windows");
            if (procs.Length == 0)
            {
                StatusDot.Fill = new SolidColorBrush(Color.FromRgb(255, 85, 85));
                TxtStatus.Text = "Waiting for Minecraft...";
                TxtStatus.Foreground = (Brush)FindResource("TextSecondary");
            }
            else if (_isSpoofed)
            {
                StatusDot.Fill = (Brush)FindResource("TextGreen");
                TxtStatus.Text = "Game Detected (Spoofed)";
                TxtStatus.Foreground = (Brush)FindResource("TextGreen");
            }
            else
            {
                StatusDot.Fill = new SolidColorBrush(Color.FromRgb(255, 185, 0));
                TxtStatus.Text = "Game Detected (Ready to Spoof)";
                TxtStatus.Foreground = new SolidColorBrush(Color.FromRgb(255, 185, 0));
            }
        }

        private void ApplyCurrentSettings()
        {
            if (_isLoading || ChkAutoSpoofOnJoin == null) return;
            bool spoofOnJoin = ChkAutoSpoofOnJoin.IsChecked == true;

            DeviceIDSpooferEngine.Instance.Apply(
                enabled: true,
                originalId: string.Empty,
                spoofOnJoin: spoofOnJoin,
                spoofOnStartup: false
            );
        }

        private void ChkAutoSpoofOnJoin_Changed(object sender, RoutedEventArgs e)
        {
            if (_isLoading) return;
            ApplyCurrentSettings();
        }

        private void BtnSpoof_Click(object sender, RoutedEventArgs e)
        {
            ApplyCurrentSettings();
            DeviceIDSpooferEngine.Instance.GenerateAndReplaceDeviceId("User Click Spoof");

            _isSpoofed = true;
            UpdateStatusUi();

            MessageBox.Show("Device ID spoofed successfully!", "Torio Device ID Spoofer", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        protected override void OnClosed(EventArgs e)
        {
            _processWatcher.Stop();
            NetworkHookManager.Instance.StopHook();
            try { FridaLoader.Cleanup(); } catch { }
            base.OnClosed(e);
        }
    }
}