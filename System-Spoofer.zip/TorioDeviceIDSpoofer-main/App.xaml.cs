﻿using System;
using System.Configuration;
using System.Data;
using System.Threading;
using System.Windows;

namespace ToriodeviceIDspoofer
{
    public partial class App : Application
    {
        private static Mutex? _mutex;
        private const string MutexName = "Global\\TorioDeviceIDSpoofer_SingleInstance_Mutex";

        public App()
        {
            _mutex = new Mutex(true, MutexName, out bool createdNew);
            if (!createdNew)
            {
                MessageBox.Show("Torio Device ID Spoofer is already running.", "Torio Device ID Spoofer", MessageBoxButton.OK, MessageBoxImage.Warning);
                Shutdown();
                return;
            }

            Network.FridaLoader.Initialize();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            if (_mutex != null)
            {
                try
                {
                    _mutex.ReleaseMutex();
                }
                catch { }
                _mutex.Dispose();
                _mutex = null;
            }
            base.OnExit(e);
        }
    }
}